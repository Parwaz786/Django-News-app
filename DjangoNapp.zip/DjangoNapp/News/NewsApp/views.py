from django.shortcuts import render

# Create your views here.
from newsapi import NewsApiClient



def index(request):
    newsapi = NewsApiClient(api_key="b5ca8fdd40dd4b64b26f06d80f0f91e1")
    topheadline = newsapi.get_top_headlines(sources="google-news-in")
    articles = topheadline['articles']

    desc = []
    news = []
    img = []

    for i in range(len(articles)):
        myarticles = articles[i]
        news.append(myarticles['title'])
        desc.append(myarticles['description'])
        img.append(myarticles['urlToImage'])


    mylist = zip(news, desc, img)
    return render(request, 'index.html', context={"mylist": mylist})


